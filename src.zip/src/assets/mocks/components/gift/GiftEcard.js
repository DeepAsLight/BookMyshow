import Card1 from "../../../images/gift/card1.png";
import Card2 from "../../../images/gift/card2.png";
import Card3 from "../../../images/gift/card3.png";
import Card4 from "../../../images/gift/card4.png";

import store1 from "../../../images/gift/store1.png";
import store2 from "../../../images/gift/store2.png";
import store3 from "../../../images/gift/store3.png";
import store4 from "../../../images/gift/store4.png";
import store5 from "../../../images/gift/store5.png";

import online1 from "../../../images/gift/online1.png";
import online2 from "../../../images/gift/online2.png";

export const GiftEcard = [
  {
    img: Card1,
  },
  {
    img: Card2,
  },
  {
    img: Card3,
  },
  {
    img: Card4,
  },
  {
    img: Card3,
  },
  {
    img: Card2,
  },
  {
    img: Card1,
  },

  {
    img: Card4,
  },
  {
    img: Card2,
  },
  {
    img: Card1,
  },
  {
    img: Card3,
  },
  {
    img: Card3,
  },
  {
    img: Card4,
  },
  {
    img: Card1,
  },

  {
    img: Card2,
  },
];

export const store = [
  {
    img: store1,
  },
  {
    img: store2,
  },
  {
    img: store3,
  },
  {
    img: store4,
  },
  {
    img: store5,
  },
];

export const online = [
  {
    img: online1,
  },
  {
    img: online2,
  },
];
