import seat1 from "../../../images/booking/seaters/seat1.png";
import seat2 from "../../../images/booking/seaters/seat2.png";
import seat3 from "../../../images/booking/seaters/seat3.png";
import seat4 from "../../../images/booking/seaters/seat4.png";
import seat5 from "../../../images/booking/seaters/seat5.png";
import seat6 from "../../../images/booking/seaters/seat6.png";
import seat9 from "../../../images/booking/seaters/seat9.png";


export const seatcount = [
  {
    img: seat1,
  },
  {
    img: seat2,
  },
  {
    img: seat3,
  },
  {
    img: seat4,
  },
  {
    img: seat5,
  },
  {
    img: seat6,
  },
  {
    img: seat6,
  },
  {
    img: seat6,
  },
  {
    img: seat9,
  },
  {
    img: seat9,
  },
];
