import premier from "../../../images/plays/premier.png";

export const filterdata = [
  {
    id: "1",
    title: `Genre`,
    sections: [
      { label: `drama` },
      { label: `action` },
      { label: `comedy` },
      { label: `thriller` },
      { label: `Adventure` },
      { label: `romantic` },
      { label: `crime` },
      { label: `mystery` },
      { label: `horror` },
    ],
  },

  {
    id: "2",
    title: `More Filters`,
    sections: [
      { label: `drama` },
      { label: `action` },
      { label: `comedy` },
      { label: `thriller` },
      { label: `Adventure` },
      { label: `romantic` },
      { label: `crime` },
      { label: `mystery` },
      { label: `horror` },
    ],
  },

  {
    id: "3",
    title: `Language`,
    sections: [
      { label: `hindi` },
      { label: `english` },
      { label: `tamil` },
      { label: `telegu` },
    ],
  },
];

export const filtereddata = [
  {
    label: `On Discount`,
  },
  {
    label: `English`,
  },
  {
    label: `Hindi`,
  },
  {
    label: `Malayalam`,
  },
  {
    label: `Bengali`,
  },
  {
    label: `Telegu`,
  },
  {
    label: `Tamil`,
  },
  {
    label: `Marathi`,
  },
  {
    label: `Spanish`,
  },
  {
    label: `On Discount`,
  },
  {
    label: `English`,
  },
  {
    label: `Hindi`,
  },
  {
    label: `Malayalam`,
  },
  {
    label: `Bengali`,
  },
  {
    label: `Telegu`,
  },
  {
    label: `Tamil`,
  },
  {
    label: `Marathi`,
  },
  {
    label: `Spanish`,
  },
];

export const filtersection = [
  {
    img: premier,
    time: `Sat, 24 Jul`,
    label: `BHAKTHA PRAHLADA Surabhi Theatre Play`,
    watchOn : `Watch On Zoom`,
    category:`Arts and Crafts`,
    rate:`₹ 250`,
    
  },
  {
    img: premier,
    time: `Sat, 24 Jul`,
    label: `BHAKTHA PRAHLADA Surabhi Theatre Play`,
    watchOn : `Watch On Zoom`,
    category:`Arts and Crafts`,
    rate:`₹ 250`,
    
  },
  {
    img: premier,
    time: `Sat, 24 Jul`,
    label: `BHAKTHA PRAHLADA Surabhi Theatre Play`,
    watchOn : `Watch On Zoom`,
    category:`Arts and Crafts`,
    rate:`₹ 250`,
    
  },
  {
    img: premier,
    time: `Sat, 24 Jul`,
    label: `BHAKTHA PRAHLADA Surabhi Theatre Play`,
    watchOn : `Watch On Zoom`,
    category:`Arts and Crafts`,
    rate:`₹ 250`,
    
  },
  {
    img: premier,
    time: `Sat, 24 Jul`,
    label: `BHAKTHA PRAHLADA Surabhi Theatre Play`,
    watchOn : `Watch On Zoom`,
    category:`Arts and Crafts`,
    rate:`₹ 250`,
    
  },
  {
    img: premier,
    time: `Sat, 24 Jul`,
    label: `BHAKTHA PRAHLADA Surabhi Theatre Play`,
    watchOn : `Watch On Zoom`,
    category:`Arts and Crafts`,
    rate:`₹ 250`,
    
  },
  {
    img: premier,
    time: `Sat, 24 Jul`,
    label: `BHAKTHA PRAHLADA Surabhi Theatre Play`,
    watchOn : `Watch On Zoom`,
    category:`Arts and Crafts`,
    rate:`₹ 250`,
    
  },
  {
    img: premier,
    time: `Sat, 24 Jul`,
    label: `BHAKTHA PRAHLADA Surabhi Theatre Play`,
    watchOn : `Watch On Zoom`,
    category:`Arts and Crafts`,
    rate:`₹ 250`,
    
  },
  {
    img: premier,
    time: `Sat, 24 Jul`,
    label: `BHAKTHA PRAHLADA Surabhi Theatre Play`,
    watchOn : `Watch On Zoom`,
    category:`Arts and Crafts`,
    rate:`₹ 250`,
    
  },
];
