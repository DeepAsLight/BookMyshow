export const Locations = [
    {
        name : `Bangalore`
    },
    {
        name : `NCR`
    },
    {
        name : `Mumbai`
    }
] 