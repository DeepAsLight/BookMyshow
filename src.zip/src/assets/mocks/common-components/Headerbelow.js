export const leftsection = [
    {
        label : "Movies",
        link : '/',
        sup:``
    },
    {
        label : "Stream",
        link : '/stream',
        sup:`New`
    },
    {
        label : "Events",
        link : `/event`,
        sup:``
    },
    {
        label : "Plays",
        link : `/plays`,
        sup:``
    },
    {
        label : "Sports",
        link : `/sports`,
        sup:``
    },
    {
        label : "Activities",
        link : `/activities`,
        sup:``
    },
    {
        label : "Buzz",
        link : `/buzz`,
        sup:``
    },
]

export const rightsection = [
    {
        label : "ListYourShow",
        link : `/list-your-show`,
        sup:`New`
    },
    {
        label : "Corporates",
        link : `/voucher`,
        sup:``
    },
    {
        label : "Offers",
        link : `/offer`,
        sup:``
    },
    {
        label : "Gift Cards",
        link : `/gift`,
        sup:``
    }
]