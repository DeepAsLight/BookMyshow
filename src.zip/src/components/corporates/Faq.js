import React from 'react'

function Faq() {
    return (
        <div>
            
        </div>
    )
}

export default Faq
